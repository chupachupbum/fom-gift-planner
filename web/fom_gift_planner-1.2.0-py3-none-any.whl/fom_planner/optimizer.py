"""
optimizer.py

Greedy weighted set-cover optimizer and focus suggestions calculator for Fields of Mistria:
- resolve_root_raw_materials
- compute_focus_suggestions
- plan_daily_gift_bag
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

from fom_planner.constants import (
    ANIMAL_FESTIVAL_ATTENDING_VENDORS,
    SATURDAY_MARKET_VENDORS,
    AvailabilityTier,
)
from fom_planner.crafting import (
    _calculate_max_craftable,
    deduct_crafting_materials,
    evaluate_craftability,
    filter_recipes_by_unlocks,
    load_recipes,
)
from fom_planner.data_loader import (
    load_alt_sources,
    load_item_locations,
    load_item_seasons,
)
from fom_planner.models import SaveData

ITEM_LOCATIONS: Dict[str, str] = load_item_locations()
ITEM_SEASONS: Dict[str, List[str]] = load_item_seasons()

_NPC_NAMES_CACHE: Optional[Dict[str, str]] = None


def _get_default_npc_names() -> Dict[str, str]:
    """Loads NPC display names from data/item_data.json if available, with memoization."""
    global _NPC_NAMES_CACHE
    if _NPC_NAMES_CACHE is not None:
        return _NPC_NAMES_CACHE
    names: Dict[str, str] = {}
    item_data_path = Path("data/item_data.json")
    if item_data_path.exists():
        try:
            with open(item_data_path, "r", encoding="utf-8") as f:
                d = json.load(f)
                npcs = d.get("npcs", {})
                for k, v in npcs.items():
                    names[str(k).strip().lower()] = str(v).strip()
        except Exception:
            pass
    _NPC_NAMES_CACHE = names
    return names


def resolve_root_raw_materials(
    item_id: str,
    recipes: Dict[str, Any],
    call_stack: Optional[Set[str]] = None,
) -> Dict[str, int]:
    """
    Recursively resolves item_id down its recipe tree to identify all root raw materials
    (items that do not have a recipe). Returns a dict of {raw_item_id: count_needed_per_item}.
    """
    if not item_id:
        return {}
    item_id = str(item_id).strip().lower()
    if not item_id:
        return {}

    if call_stack is None:
        call_stack = set()

    if not recipes or not isinstance(recipes, dict) or item_id in call_stack or item_id not in recipes:
        return {item_id: 1}

    recipe = recipes.get(item_id)
    if not isinstance(recipe, dict):
        return {item_id: 1}

    ingredients = recipe.get("ingredients", [])
    if not isinstance(ingredients, list) or not ingredients:
        return {item_id: 1}

    call_stack.add(item_id)
    try:
        raw_mats: Dict[str, int] = {}
        for ing in ingredients:
            if not isinstance(ing, dict):
                continue
            ing_id = str(ing.get("item_id", "")).strip().lower()
            if not ing_id:
                continue
            try:
                ing_count = max(1, int(round(float(ing.get("count", 1)))))
            except (ValueError, TypeError):
                ing_count = 1
            sub_raw = resolve_root_raw_materials(ing_id, recipes, call_stack)
            for raw_id, count in sub_raw.items():
                raw_mats[raw_id] = raw_mats.get(raw_id, 0) + count * ing_count
        return raw_mats
    finally:
        call_stack.remove(item_id)


def filter_remaining_items_for_focus(
    remaining_items_map: Optional[Dict[str, Dict[str, Any]]],
    focus_npcs: Optional[Union[Set[str], List[str], str]] = None,
) -> Dict[str, Dict[str, Set[str]]]:
    """
    Filters remaining_items_map to only include preferences for the specified focus NPCs.
    If focus_npcs is empty/None/falsy, returns remaining_items_map untouched.
    """
    if not remaining_items_map or not isinstance(remaining_items_map, dict):
        return remaining_items_map if remaining_items_map is not None else {}

    if not focus_npcs:
        return remaining_items_map

    if isinstance(focus_npcs, (str, bytes)):
        norm_npcs = {x.strip().lower() for x in str(focus_npcs).split(",") if x.strip()}
    elif hasattr(focus_npcs, "__iter__"):
        norm_npcs = {str(x).strip().lower() for x in focus_npcs if x is not None and str(x).strip()}
    else:
        norm_npcs = set()

    if not norm_npcs:
        return remaining_items_map

    def _norm_set(val: Any) -> Set[str]:
        if val is None:
            return set()
        if isinstance(val, (str, bytes)):
            s = str(val).strip().lower()
            return {s} if s else set()
        if hasattr(val, "__iter__"):
            return {str(x).strip().lower() for x in val if x is not None and str(x).strip()}
        return set()

    filtered_map: Dict[str, Dict[str, Set[str]]] = {}
    for item_id, targets in remaining_items_map.items():
        if not item_id or not isinstance(targets, dict):
            continue
        item_clean = str(item_id).strip().lower()
        if not item_clean:
            continue
        loved = _norm_set(targets.get("loved")) & norm_npcs
        liked = _norm_set(targets.get("liked")) & norm_npcs

        if loved or liked:
            entry = {k: v for k, v in targets.items() if k not in ("loved", "liked")}
            entry["loved"] = loved
            entry["liked"] = liked
            filtered_map[item_clean] = entry

    return filtered_map


def compute_focus_suggestions(
    remaining_items_map: Dict[str, Dict[str, Set[str]]],
    inventory: Optional[Dict[str, int]] = None,
    recipes: Optional[Dict[str, Any]] = None,
    item_metadata: Optional[Dict[str, dict]] = None,
    top_n: int = 20,
    item_locations: Optional[Dict[str, str]] = None,
    focus_sort: str = "impact",
    current_season: Optional[str] = None,
    item_seasons: Optional[Dict[str, List[str]]] = None,
    seasonal_boost: float = 2.0,
    focus_mode_enabled: bool = False,
    focus_npcs: Optional[Union[Set[str], List[str], str]] = None,
) -> List[Dict[str, Any]]:
    """
    Computes a ranked list of top insufficient items (raw materials and direct gifts)
    blocking pending NPC gift opportunities.

    Algorithm:
      1. For each item in remaining_items_map (optionally filtered by focus NPCs),
         recursively resolves its recipe tree to identify all root raw material ingredients needed.
      2. Sums total demand for each raw ingredient across ALL pending gift-NPC pairs.
      3. Accounts for player's owned inventory, including:
         - Pre-crafted/finished gifts in inventory that directly satisfy pending NPC preferences.
         - Processed/intermediate goods (e.g. Flour for Wheat, Sugar for Sugar Cane, Rice for
           Rice Stalk, Cheese/Butter for Milk) converting their surplus towards root raw material inventory.
      4. Subtracts player's effective inventory pool to find deficit = demand - inventory.
      5. Identifies items where deficit > 0.
      6. Ranks by configured focus_sort mode:
         - 'impact' (default): (1) blocked NPC-gift pairs count descending,
                               (2) deficit count descending (tiebreaker),
                               (3) display name ascending (tiebreaker).
         - 'deficit': (1) deficit count descending,
                      (2) blocked NPC-gift pairs count descending (tiebreaker),
                      (3) display name ascending (tiebreaker).
         - 'quick-wins': (1) deficit count ascending,
                         (2) blocked NPC-gift pairs count descending (tiebreaker),
                         (3) display name ascending (tiebreaker).
      7. Returns top N items with 1-based rank, deficit, location hints, and blocked NPCs list.
    """
    if top_n <= 0:
        return []

    if focus_mode_enabled and focus_npcs:
        effective_remaining_map = filter_remaining_items_for_focus(remaining_items_map, focus_npcs)
    else:
        effective_remaining_map = remaining_items_map

    if recipes is None:
        recipes = load_recipes()
    if item_metadata is None:
        item_metadata = {}

    clean_inv: Dict[str, int] = {}
    if inventory and isinstance(inventory, dict):
        for k, v in inventory.items():
            if not k:
                continue
            k_clean = str(k).strip().lower()
            if not k_clean:
                continue
            try:
                val = int(round(float(v)))
                if val > 0:
                    clean_inv[k_clean] = clean_inv.get(k_clean, 0) + val
            except (ValueError, TypeError):
                pass

    def _normalize_npc_set(val: Any) -> Set[str]:
        if val is None:
            return set()
        if isinstance(val, (str, bytes)):
            s = str(val).strip()
            return {s} if s else set()
        if hasattr(val, "__iter__"):
            res = set()
            for x in val:
                if x is not None:
                    s = str(x).strip()
                    if s:
                        res.add(s)
            return res
        return set()

    # Identify intermediate items in recipes (crafted items used as ingredients in other recipes)
    all_recipe_ingredients: Set[str] = set()
    if recipes and isinstance(recipes, dict):
        for r in recipes.values():
            if isinstance(r, dict):
                for ing in r.get("ingredients", []):
                    if isinstance(ing, dict) and ing.get("item_id"):
                        all_recipe_ingredients.add(str(ing["item_id"]).strip().lower())
    intermediate_items: Set[str] = (
        {k.strip().lower() for k in recipes.keys()} & all_recipe_ingredients
        if recipes and isinstance(recipes, dict)
        else set()
    )

    # Track direct gift demand for intermediate items to reserve them before converting surplus
    direct_gift_demand: Dict[str, int] = {}
    if effective_remaining_map and isinstance(effective_remaining_map, dict):
        for item_id, targets in effective_remaining_map.items():
            if item_id and isinstance(targets, dict):
                item_clean = str(item_id).strip().lower()
                pending = _normalize_npc_set(targets.get("loved")) | _normalize_npc_set(targets.get("liked"))
                direct_gift_demand[item_clean] = len(pending)

    # Calculate effective inventory for root raw materials (including equivalents from surplus intermediate goods)
    effective_inv: Dict[str, int] = dict(clean_inv)
    for item_id, count in clean_inv.items():
        if item_id in intermediate_items:
            needed_direct = direct_gift_demand.get(item_id, 0)
            surplus_count = max(0, count - needed_direct)
            if surplus_count > 0:
                sub_raws = resolve_root_raw_materials(item_id, recipes)
                for raw_id, raw_cnt in sub_raws.items():
                    if raw_id != item_id:
                        effective_inv[raw_id] = effective_inv.get(raw_id, 0) + raw_cnt * surplus_count

    raw_demand: Dict[str, int] = {}
    raw_blocked_pairs: Dict[str, Set[Tuple[str, str]]] = {}
    raw_pair_costs: Dict[str, Dict[Tuple[str, str], int]] = {}

    if effective_remaining_map and isinstance(effective_remaining_map, dict):
        for item_id, targets in effective_remaining_map.items():
            if not item_id or not isinstance(targets, dict):
                continue
            item_clean = str(item_id).strip().lower()
            if not item_clean:
                continue
            loved_set = _normalize_npc_set(targets.get("loved"))
            liked_set = _normalize_npc_set(targets.get("liked"))
            pending_npcs = loved_set | liked_set
            if not pending_npcs:
                continue

            # If player already owns finished copies of this crafted gift, they don't need raw ingredients
            have_finished = clean_inv.get(item_clean, 0) if (recipes and item_clean in recipes) else 0
            total_needed = len(pending_npcs)
            needed_to_craft = max(0, total_needed - have_finished)

            if not recipes or item_clean not in recipes:
                # Raw item (not craftable)
                raw_demand[item_clean] = raw_demand.get(item_clean, 0) + total_needed
                if item_clean not in raw_blocked_pairs:
                    raw_blocked_pairs[item_clean] = set()
                    raw_pair_costs[item_clean] = {}
                for nid in pending_npcs:
                    pair = (str(nid), item_clean)
                    raw_blocked_pairs[item_clean].add(pair)
                    raw_pair_costs[item_clean][pair] = 1
            else:
                # Crafted item
                if needed_to_craft > 0:
                    raw_mats = resolve_root_raw_materials(item_clean, recipes)
                    for raw_id, count_per_gift in raw_mats.items():
                        if not raw_id:
                            continue
                        raw_demand[raw_id] = raw_demand.get(raw_id, 0) + count_per_gift * needed_to_craft
                        if raw_id not in raw_blocked_pairs:
                            raw_blocked_pairs[raw_id] = set()
                            raw_pair_costs[raw_id] = {}
                        for nid in list(pending_npcs)[:needed_to_craft]:
                            pair = (str(nid), item_clean)
                            raw_blocked_pairs[raw_id].add(pair)
                            raw_pair_costs[raw_id][pair] = count_per_gift

    season_map = item_seasons if item_seasons is not None else ITEM_SEASONS
    clean_season = str(current_season).strip().lower() if current_season else None
    if clean_season in ("all", "all seasons", "all-seasons", ""):
        clean_season = None
    elif clean_season == "autumn":
        clean_season = "fall"

    suggestions: List[Dict[str, Any]] = []
    for raw_id, total_dem in raw_demand.items():
        inv_count = effective_inv.get(raw_id, 0)
        deficit = total_dem - inv_count
        if deficit > 0:
            if clean_season and season_map and raw_id in season_map:
                avail_seasons = [
                    "fall" if str(s).strip().lower() == "autumn" else str(s).strip().lower()
                    for s in season_map[raw_id]
                ]
                if clean_season not in avail_seasons:
                    continue

            pair_map = raw_pair_costs.get(raw_id, {})
            # Sort deterministically by (item_id, npc_id)
            sorted_pairs = sorted(pair_map.items(), key=lambda x: (x[0][1], x[0][0]))
            remaining_inv = inv_count
            ready_count = 0
            blocked_pairs_list = []
            for pair, cost in sorted_pairs:
                if remaining_inv >= cost:
                    ready_count += 1
                    remaining_inv -= cost
                else:
                    blocked_pairs_list.append(pair)
            total_pairs = len(sorted_pairs)
            blocked_count = total_pairs - ready_count
            blocked_npcs = sorted(list({p[0] for p in blocked_pairs_list}))

            meta = item_metadata.get(raw_id, {}) if isinstance(item_metadata, dict) else {}
            if isinstance(meta, dict):
                disp_name = meta.get("display_name") or raw_id.replace("_", " ").title()
            elif isinstance(meta, str) and meta.strip():
                disp_name = meta.strip()
            else:
                disp_name = raw_id.replace("_", " ").title()
            loc_map = item_locations if item_locations is not None else ITEM_LOCATIONS
            location = loc_map.get(raw_id, "")

            # Calculate seasonal boost (single-season items get seasonal_boost, multi-season get tiered boost)
            boost = 1.0
            item_seasons_list = season_map.get(raw_id, []) if season_map else []
            is_seasonal = bool(season_map and raw_id in season_map and item_seasons_list)
            safe_boost = max(1.0, float(seasonal_boost if seasonal_boost is not None else 1.0))
            if is_seasonal and safe_boost > 1.0:
                if len(item_seasons_list) == 1:
                    boost = safe_boost
                else:
                    boost = 1.0 + (safe_boost - 1.0) * 0.5

            weighted_impact = blocked_count * boost

            suggestions.append({
                "item_id": raw_id,
                "item_name": disp_name,
                "blocked_pairs": blocked_count,
                "ready_pairs": ready_count,
                "total_pairs": total_pairs,
                "demand": total_dem,
                "inventory": inv_count,
                "deficit": deficit,
                "location_hint": location,
                "seasonal_boost": boost,
                "weighted_impact": weighted_impact,
                "seasons": item_seasons_list,
                "is_seasonal": is_seasonal,
                "blocked_npcs": blocked_npcs,
            })

    # Sort based on configured focus_sort mode
    clean_sort = str(focus_sort or "impact").strip().lower()
    if clean_sort == "deficit":
        # (1) deficit descending, (2) weighted impact descending, (3) name ascending
        suggestions.sort(key=lambda x: (-x["deficit"], -x["weighted_impact"], str(x["item_name"]).lower()))
    elif clean_sort == "quick-wins":
        # (1) deficit ascending, (2) weighted impact descending, (3) name ascending
        suggestions.sort(key=lambda x: (x["deficit"], -x["weighted_impact"], str(x["item_name"]).lower()))
    else:
        # Default: 'impact' -> (1) weighted impact descending, (2) deficit descending, (3) name ascending
        suggestions.sort(key=lambda x: (-x["weighted_impact"], -x["deficit"], str(x["item_name"]).lower()))

    # Assign 1-indexed ranks and trim to top_n
    result: List[Dict[str, Any]] = []
    for rank, item in enumerate(suggestions[:top_n], start=1):
        item["rank"] = rank
        result.append(item)

    return result


def compute_focus_recipes(
    all_recipes: Optional[Dict[str, Any]] = None,
    unlocked_recipe_ids: Optional[Set[str]] = None,
    remaining_items_map: Optional[Dict[str, Dict[str, Any]]] = None,
    recipe_sources: Optional[Dict[str, str]] = None,
    top_n: Optional[int] = 10,
    recipes: Optional[Dict[str, Any]] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Ranks locked cooking recipes by the number of pending ungifted NPC preferences
    (loved + liked combined) satisfied by their output dish.

    Parameters:
      all_recipes: Canonical recipe database (all 186 recipes). If None, falls back
                   to recipes or load_recipes().
      unlocked_recipe_ids: Set of lowercased recipe IDs unlocked by the player.
                           If None (e.g. no save data or mock save), returns empty list.
      remaining_items_map: Mapping of item_id -> {"loved": set(), "liked": set()}
                           representing ungifted NPC preferences.
      recipe_sources: Mapping of recipe_id -> unlock location string.
      top_n: Maximum number of ranked suggestions to return (default: 10). If None, returns all.
      recipes: Alias for all_recipes for keyword compatibility.

    Returns:
      Tuple of (focus_recipes, recipe_unlock_stats):
        - focus_recipes: Top N ranked dicts with keys:
            ['rank', 'recipe_id', 'display_name', 'impact', 'unlock_source']
        - recipe_unlock_stats: Dict with keys:
            ['total_cooking_recipes', 'unlocked_recipes_count', 'unlocked_percentage',
             'total_cooking', 'unlocked_count', 'has_unlock_data']
    """
    if all_recipes is not None:
        recipe_dict = all_recipes
    elif recipes is not None:
        recipe_dict = recipes
    else:
        recipe_dict = load_recipes()

    if not isinstance(recipe_dict, dict):
        recipe_dict = {}

    # 1. Identify cooking recipes only (milling recipes are always unlocked)
    cooking_recipes: Dict[str, dict] = {}
    for rid, rdata in recipe_dict.items():
        if not rid or not isinstance(rdata, dict):
            continue
        src = str(rdata.get("source", "")).strip().lower()
        if src == "cooking":
            cooking_recipes[str(rid).strip().lower()] = rdata

    total_cooking = len(cooking_recipes)

    # 2. Compute unlock statistics
    has_unlock_data = unlocked_recipe_ids is not None
    norm_unlocked: Set[str] = set()
    if has_unlock_data and isinstance(unlocked_recipe_ids, (set, list, tuple, frozenset)):
        norm_unlocked = {str(x).strip().lower() for x in unlocked_recipe_ids if x}

    unlocked_cooking_count = sum(1 for rid in cooking_recipes if rid in norm_unlocked) if has_unlock_data else 0
    unlocked_pct = (unlocked_cooking_count / total_cooking * 100.0) if (total_cooking > 0 and has_unlock_data) else 0.0

    recipe_unlock_stats = {
        "total_cooking_recipes": total_cooking,
        "unlocked_recipes_count": unlocked_cooking_count,
        "unlocked_percentage": unlocked_pct,
        "total_cooking": total_cooking,
        "unlocked_count": unlocked_cooking_count,
        "has_unlock_data": has_unlock_data,
    }

    # 3. Handle edge cases where suggestions list should be empty:
    #    - No save data / no unlock data provided (unlocked_recipe_ids is None)
    #    - All cooking recipes unlocked
    #    - top_n <= 0 or total_cooking == 0
    if not has_unlock_data or unlocked_cooking_count >= total_cooking or (top_n is not None and top_n <= 0) or total_cooking == 0:
        return [], recipe_unlock_stats

    # Helper to safely parse NPC sets from remaining_items_map
    def _parse_npc_set(val: Any) -> Set[str]:
        if val is None:
            return set()
        if isinstance(val, (str, bytes)):
            s = str(val).strip()
            return {s} if s else set()
        if hasattr(val, "__iter__"):
            return {str(x).strip() for x in val if x and str(x).strip()}
        return set()

    # 4. Filter for locked cooking recipes and calculate impact
    candidates: List[Dict[str, Any]] = []
    for rid, rdata in cooking_recipes.items():
        if rid in norm_unlocked:
            continue

        out_dish_id = str(rdata.get("item_id") or rid).strip().lower()
        disp_name = str(rdata.get("display_name") or rid.replace("_", " ").title()).strip()

        source_str = "Unknown"
        if recipe_sources and isinstance(recipe_sources, dict):
            src_val = recipe_sources.get(rid) or recipe_sources.get(out_dish_id)
            if src_val and str(src_val).strip():
                source_str = str(src_val).strip()

        impact = 0
        if remaining_items_map and isinstance(remaining_items_map, dict):
            targets = remaining_items_map.get(out_dish_id) or remaining_items_map.get(rid)
            if targets and isinstance(targets, dict):
                loved_set = _parse_npc_set(targets.get("loved"))
                liked_set = _parse_npc_set(targets.get("liked"))
                impact = len(loved_set | liked_set)
            elif isinstance(targets, (set, list, tuple)):
                impact = len(_parse_npc_set(targets))

        candidates.append({
            "recipe_id": rid,
            "display_name": disp_name,
            "impact": impact,
            "unlock_source": source_str,
        })

    # 5. Rank: impact descending, display_name ascending (case-insensitive), recipe_id ascending
    candidates.sort(key=lambda x: (-x["impact"], str(x["display_name"]).lower(), str(x["recipe_id"]).lower()))

    # 6. Assign 1-indexed rank and truncate to top_n
    ranked_recipes: List[Dict[str, Any]] = []
    limit = len(candidates) if top_n is None else top_n
    for rank, item in enumerate(candidates[:limit], start=1):
        entry = dict(item)
        entry["rank"] = rank
        ranked_recipes.append(entry)

    return ranked_recipes, recipe_unlock_stats


_TREE_ITEM_ALIASES: Dict[str, str] = {
    "milk": "cow_milk",
    "cow_milk": "milk",
    "golden_milk": "golden_cow_milk",
    "golden_cow_milk": "golden_milk",
    "wood": "basic_wood",
    "basic_wood": "wood",
    "stone": "ore_stone",
    "ore_stone": "stone",
    "rice_ball": "riceball",
    "riceball": "rice_ball",
    "tea": "cup_of_tea",
    "cup_of_tea": "tea",
}


def build_focus_crafting_trees(
    focus_suggestions: List[Dict[str, Any]],
    recipes: Optional[Dict[str, Any]] = None,
    remaining_items_map: Optional[Dict[str, Dict[str, Any]]] = None,
    alt_sources: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    item_metadata: Optional[Dict[str, dict]] = None,
    npc_names: Optional[Dict[str, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Builds a downstream crafting dependency tree for each focus suggestion blocker item.

    For a blocker item like 'milk' / 'cow_milk', produces:
      milk
      ├── cheese (mill: milk → cheese)
      │   ├── cheesecake (craft) [🐔 Chicken Statue: 100 beads]
      │   └── quiche (craft)
      └── butter (mill: milk → butter)
          └── croissant (craft)

    Each node includes:
      - item_id, item_name
      - alt_sources: list of alternate acquisition methods from alt_sources.json
      - children: list of downstream product nodes
      - gift_npcs: sorted list of NPC names who want this item as a gift (leaf/product nodes)
      - sprite_url: URL path to the item's sprite image
    """
    if not focus_suggestions:
        return []
    if recipes is None:
        recipes = {}
    if remaining_items_map is None:
        remaining_items_map = {}
    if alt_sources is None:
        alt_sources = {}
    if item_metadata is None:
        item_metadata = {}

    # Normalize remaining_items_map keys to lowercase
    norm_remaining_map: Dict[str, Any] = {}
    if isinstance(remaining_items_map, dict):
        for k, v in remaining_items_map.items():
            if k is not None:
                norm_remaining_map[str(k).strip().lower()] = v

    pending_gift_ids: Set[str] = set(norm_remaining_map.keys())

    # Build reverse index: ingredient_id -> set of recipe_ids that use it
    ingredient_to_recipes: Dict[str, Set[str]] = {}
    for rid, rdata in recipes.items():
        if not isinstance(rdata, dict):
            continue
        for ing in rdata.get("ingredients", []):
            if isinstance(ing, dict) and ing.get("item_id"):
                ing_id = str(ing["item_id"]).strip().lower()
                ingredient_to_recipes.setdefault(ing_id, set()).add(str(rid).strip().lower())

    def _get_display_name(item_id: str) -> str:
        meta = item_metadata.get(item_id, {})
        if isinstance(meta, dict) and meta.get("display_name"):
            return meta["display_name"]
        if item_id in _TREE_ITEM_ALIASES:
            meta_alias = item_metadata.get(_TREE_ITEM_ALIASES[item_id], {})
            if isinstance(meta_alias, dict) and meta_alias.get("display_name"):
                return meta_alias["display_name"]
        rdata = recipes.get(item_id, {})
        if isinstance(rdata, dict) and rdata.get("display_name"):
            return rdata["display_name"]
        if item_id in _TREE_ITEM_ALIASES:
            rdata_alias = recipes.get(_TREE_ITEM_ALIASES[item_id], {})
            if isinstance(rdata_alias, dict) and rdata_alias.get("display_name"):
                return rdata_alias["display_name"]
        return item_id.replace("_", " ").title()

    def _is_pending_gift(item_id: str) -> bool:
        if item_id in pending_gift_ids:
            return True
        if item_id in _TREE_ITEM_ALIASES and _TREE_ITEM_ALIASES[item_id] in pending_gift_ids:
            return True
        return False

    def _get_gift_npcs(item_id: str) -> List[str]:
        targets = norm_remaining_map.get(item_id)
        if targets is None and item_id in _TREE_ITEM_ALIASES:
            targets = norm_remaining_map.get(_TREE_ITEM_ALIASES[item_id])
        if not targets:
            return []
        if isinstance(targets, dict):
            loved = targets.get("loved") or set()
            liked = targets.get("liked") or set()
            if isinstance(loved, (list, tuple)):
                loved = set(loved)
            if isinstance(liked, (list, tuple)):
                liked = set(liked)
            all_n = set(loved) | set(liked)
        elif isinstance(targets, (set, list, tuple)):
            all_n = set(targets)
        else:
            all_n = set()
        npcs = set()
        for n in all_n:
            if not n:
                continue
            n_str = str(n).strip()
            if npc_names and n_str.lower() in npc_names:
                npcs.add(npc_names[n_str.lower()])
            else:
                npcs.add(n_str.capitalize())
        return sorted(npcs)

    def _get_alt_sources(item_id: str) -> List[Dict[str, Any]]:
        sources = alt_sources.get(item_id, [])
        if not sources and item_id in _TREE_ITEM_ALIASES:
            sources = alt_sources.get(_TREE_ITEM_ALIASES[item_id], [])
        return sources or []

    def _has_pending_downstream(item_id: str, seen: Set[str]) -> bool:
        """Checks if any downstream product is a pending gift."""
        if item_id in seen:
            return False
        seen.add(item_id)

        downstream = ingredient_to_recipes.get(item_id, set())
        if item_id in _TREE_ITEM_ALIASES:
            downstream = downstream | ingredient_to_recipes.get(_TREE_ITEM_ALIASES[item_id], set())

        for rid in sorted(downstream):
            rdata = recipes.get(rid, {})
            product = str(rdata.get("item_id", rid)).strip().lower()
            if not product:
                continue
            if _is_pending_gift(product):
                return True
            if _has_pending_downstream(product, seen):
                return True
        return False

    def _build_subtree(item_id: str, visited: Set[str]) -> Optional[Dict[str, Any]]:
        """Recursively builds the downstream tree from an item."""
        if item_id in visited:
            return None
        visited.add(item_id)
        if item_id in _TREE_ITEM_ALIASES:
            visited.add(_TREE_ITEM_ALIASES[item_id])

        node: Dict[str, Any] = {
            "item_id": item_id,
            "item_name": _get_display_name(item_id),
            "alt_sources": _get_alt_sources(item_id),
            "gift_npcs": _get_gift_npcs(item_id),
            "children": [],
            "sprite_url": f"/assets/sprites/items/{item_id}",
        }

        downstream_recipes = ingredient_to_recipes.get(item_id, set())
        if item_id in _TREE_ITEM_ALIASES:
            downstream_recipes = downstream_recipes | ingredient_to_recipes.get(_TREE_ITEM_ALIASES[item_id], set())

        products_seen: Set[str] = set()
        for rid in sorted(downstream_recipes):
            rdata = recipes.get(rid, {})
            product_id = str(rdata.get("item_id", rid)).strip().lower()
            if not product_id or product_id in products_seen:
                continue
            products_seen.add(product_id)

            if _is_pending_gift(product_id) or _has_pending_downstream(product_id, set()):
                child = _build_subtree(product_id, visited.copy())
                if child:
                    node["children"].append(child)

        return node

    trees: List[Dict[str, Any]] = []
    for suggestion in focus_suggestions:
        if not isinstance(suggestion, dict):
            continue
        item_id = str(suggestion.get("item_id", "")).strip().lower()
        if not item_id:
            continue
        tree = _build_subtree(item_id, set())
        if tree:
            if suggestion.get("item_name") and tree.get("item_name") != suggestion["item_name"]:
                tree["item_name"] = suggestion["item_name"]
            trees.append(tree)

    return trees


def _split_compound_locations(loc_str: str) -> List[str]:
    """
    Splits compound location strings on ' / ' ONLY when outside parentheses ().
    Preserves seasonal/conditional slashes inside () such as 'Fishing (River, Spring / Fall)'.
    """
    if not loc_str or not isinstance(loc_str, str):
        return []
    s = loc_str.strip()
    if not s:
        return []
    parts: List[str] = []
    current: List[str] = []
    depth = 0
    i = 0
    n = len(s)
    while i < n:
        char = s[i]
        if char == "(":
            depth += 1
            current.append(char)
            i += 1
        elif char == ")":
            depth = max(0, depth - 1)
            current.append(char)
            i += 1
        elif depth == 0 and s[i:i + 3] == " / ":
            part = "".join(current).strip()
            if part:
                parts.append(part)
            current = []
            i += 3
        else:
            current.append(char)
            i += 1
    part = "".join(current).strip()
    if part:
        parts.append(part)
    return parts


def normalize_source_name(name: str) -> str:
    """
    Normalizes location and vendor strings into canonical physical source names.
    Merges mine biomes, 'The Mill (...)', 'Hayden's Ranch Shop', 'Sleeping Dragon Inn', etc.
    """
    s = name.strip()
    if not s:
        return s

    for prefix in (
        "The Upper Mines", "Upper Mines",
        "The Tide Caverns", "Tide Caverns",
        "The Deep Earth", "Deep Earth",
        "The Lava Caves", "Lava Caves",
        "The Ancient Ruins", "Ancient Ruins",
    ):
        if s.startswith(prefix):
            clean_prefix = prefix[4:] if prefix.startswith("The ") else prefix
            suffix = s[len(prefix):].strip()
            return f"{clean_prefix} {suffix}".strip()

    s_lower = s.lower()
    if s_lower.startswith("the mill") or s_lower.startswith("mill (") or s_lower == "mill":
        return "The Mill"
    if "hayden" in s_lower and ("shop" in s_lower or "ranch" in s_lower):
        return "Hayden's Ranch Shop"
    if "sleeping dragon" in s_lower:
        return "Sleeping Dragon Inn"
    if "smelter" in s_lower or "blacksmith smelter" in s_lower:
        return "Blacksmith Smelter"
    if "dragon forge" in s_lower:
        return "The Dragon Forge"
    if "stone refinery" in s_lower:
        return "Stone Refinery"

    return s


def classify_source_tier(source_name: str, source_type: Optional[str] = None) -> str:
    """
    Classifies a source into 'Quick', 'Grind', or 'Farm' tiers.
    """
    if source_type in ("mimic", "fishing"):
        return "Grind"
    if source_type in ("living_off_the_land",):
        return "Farm"
    if source_type in (
        "shop", "inn", "market_stall", "festival", "mill", "quest",
        "museum", "date", "chicken_statue", "wishing_well"
    ):
        return "Quick"

    nl = source_name.lower().strip()

    # Quick: shops, mill, smelter/forge, inn, cooking, bug catching, quest, museum, festivals, apiary
    quick_keywords = (
        "general store", "balor", "hayden", "tackle shop", "darcy", "stall", "shop",
        "the mill", "mill", "smelter", "forge", "refinery", "sleeping dragon", "inn",
        "cooking", "kitchen", "catching", "bug catching", "quest", "request board",
        "museum", "festival", "market", "chicken statue", "wishing well", "date", "apiary"
    )
    if any(k in nl for k in quick_keywords):
        return "Quick"

    # Grind activities that take place in wild/farm areas
    grind_starts = (
        "foraging", "digging", "fishing", "diving", "woodcutting",
        "chopping", "breaking rocks", "shaking trees"
    )
    if any(nl.startswith(k) or f" {k}" in nl for k in grind_starts):
        return "Grind"

    # Farm: ranch, animal care, farm crops/flowers/orchard
    farm_keywords = (
        "ranch", "animal care", "farm", "crop", "flower", "orchard",
        "fruit tree", "coop", "barn"
    )
    if any(k in nl for k in farm_keywords):
        return "Farm"

    # Grind: mines, caves, caverns, default for wild locations
    return "Grind"


def compute_source_priorities(
    focus_suggestions: List[Dict[str, Any]],
    item_locations: Optional[Dict[str, str]] = None,
    alt_sources: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    npc_names: Optional[Dict[str, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Groups focus suggestions by physical acquisition source (primary + alternate),
    scores each source by the sum of blocked_pairs of items obtainable there,
    classifies sources into Quick/Grind/Farm tiers, and returns a structured list.
    """
    if not focus_suggestions or not isinstance(focus_suggestions, list):
        return []

    loc_map = item_locations if item_locations is not None else ITEM_LOCATIONS
    alt_map = load_alt_sources() if alt_sources is None else alt_sources
    if not npc_names:
        npc_names = _get_default_npc_names()

    sources_acc: Dict[str, Dict[str, Any]] = {}

    for item in focus_suggestions:
        if not isinstance(item, dict):
            continue
        item_id = str(item.get("item_id", "")).strip().lower()
        if not item_id:
            continue
        item_name = item.get("item_name") or item_id.replace("_", " ").title()
        deficit = int(item.get("deficit", 0))
        blocked_pairs = int(item.get("blocked_pairs", 0))
        blocked_npcs = item.get("blocked_npcs", [])

        disp_npcs: List[str] = []
        for nid in blocked_npcs:
            if not nid:
                continue
            n_str = str(nid).strip()
            if npc_names and n_str.lower() in npc_names:
                disp_npcs.append(npc_names[n_str.lower()])
            elif npc_names and n_str in npc_names:
                disp_npcs.append(npc_names[n_str])
            else:
                disp_npcs.append(n_str.capitalize())

        item_sources: Set[Tuple[str, str]] = set()

        # Primary locations
        raw_loc = loc_map.get(item_id, "")
        if not raw_loc and item_id in _TREE_ITEM_ALIASES:
            raw_loc = loc_map.get(_TREE_ITEM_ALIASES[item_id], "")
        if raw_loc:
            for sub in _split_compound_locations(raw_loc):
                norm = normalize_source_name(sub)
                tier = classify_source_tier(norm)
                item_sources.add((norm, tier))

        # Alternate sources
        alt_list = alt_map.get(item_id, [])
        if not alt_list and item_id in _TREE_ITEM_ALIASES:
            alt_list = alt_map.get(_TREE_ITEM_ALIASES[item_id], [])
        for src in (alt_list or []):
            st = src.get("type")
            v = src.get("vendor") or src.get("location")
            if not v:
                if st == "chicken_statue":
                    v = "Chicken Statue"
                elif st == "wishing_well":
                    v = "Wishing Well"
                elif st == "living_off_the_land":
                    v = "Living Off The Land"
                else:
                    v = str(st).replace("_", " ").title()
            norm = normalize_source_name(v)
            tier = classify_source_tier(norm, source_type=st)
            item_sources.add((norm, tier))

        # Fallback if no location found
        if not item_sources:
            item_sources.add(("Other / Unknown", "Grind"))

        for src_name, tier in item_sources:
            if src_name not in sources_acc:
                sources_acc[src_name] = {
                    "source_name": src_name,
                    "tier": tier,
                    "items": {},
                    "benefited_npcs": set(),
                }
            entry = sources_acc[src_name]
            if item_id not in entry["items"]:
                entry["items"][item_id] = {
                    "item_id": item_id,
                    "item_name": item_name,
                    "deficit": deficit,
                    "blocked_pairs": blocked_pairs,
                }
            for d in disp_npcs:
                entry["benefited_npcs"].add(d)

    result: List[Dict[str, Any]] = []
    for src_name, data in sources_acc.items():
        items_list = list(data["items"].values())
        items_list.sort(key=lambda x: (
            -x.get("blocked_pairs", 0),
            -x.get("deficit", 0),
            str(x.get("item_name", "")).lower(),
        ))
        total_score = sum(it.get("blocked_pairs", 0) for it in items_list)
        result.append({
            "source_name": data["source_name"],
            "tier": data["tier"],
            "total_score": total_score,
            "items": items_list,
            "benefited_npcs": sorted(list(data["benefited_npcs"])),
        })

    tier_order = {"Quick": 0, "Grind": 1, "Farm": 2}
    result.sort(key=lambda x: (
        tier_order.get(x["tier"], 99),
        -x["total_score"],
        str(x["source_name"]).lower(),
    ))
    return result


def plan_daily_gift_bag(
    save: Optional[SaveData] = None,
    npc_gift_definitions: Optional[Dict[str, dict]] = None,
    item_metadata: Optional[Dict[str, dict]] = None,
    mode: str = "auto",
    max_slots: int = 20,
    loved_weight: int = 3,
    liked_weight: int = 1,
    vendor_boost: float = 1.5,
    exclude_npcs: Optional[Set[str]] = None,
    force_all_npcs: bool = False,
    inventory: Optional[Dict[str, int]] = None,
    recipes: Optional[Dict[str, Any]] = None,
    all_recipes: Optional[Dict[str, Any]] = None,
    item_locations: Optional[Dict[str, str]] = None,
    focus_sort: str = "impact",
    recipe_sources: Optional[Dict[str, str]] = None,
    current_season: Optional[str] = None,
    item_seasons: Optional[Dict[str, List[str]]] = None,
    all_seasons: bool = False,
    seasonal_boost: float = 2.0,
    focus_top_n: int = 20,
    alt_sources: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    focus_mode_enabled: bool = False,
    focus_npcs: Optional[Union[Set[str], List[str], str]] = None,
) -> dict:
    """
    Computes the optimal bag loadout for today's gifting session with inventory awareness.

    Modes:
      - 'auto' / 'today': Use save calendar date (weekday = 26 townsfolk, Saturday = 34 NPCs)
      - 'saturday' / 'market': Simulate Saturday Market day (all 34 NPCs with vendor boost)
      - 'market-only': Plan only for the 8 visiting Saturday Market vendors
      - 'townsfolk' / 'weekday': Plan only for the 26 permanent townsfolk
      - 'all': Plan for all 34 NPCs regardless of day

    Returns a dict with:
        - bag_plan: list of bag slot dicts (including availability_tier, status, status_badge, crafting_chain)
        - npc_progress: dict of npc_id -> stats
        - covered_npcs: set of npc_ids covered today
        - target_npcs: set of npc_ids included in planning
        - remaining_items_map: dict of ungifted item_id -> {"loved": set(), "liked": set()}
        - focus_suggestions: top 20 insufficient blocker items
        - focus_recipes: top 10 ranked locked cooking recipes
        - recipe_unlock_stats: summary stats of cooking recipe unlocks
        - overall_stats: summary counts
    """
    if exclude_npcs is None:
        exclude_npcs = set()
    if npc_gift_definitions is None:
        npc_gift_definitions = {}
    if item_metadata is None:
        item_metadata = {}
    if recipes is None:
        recipes = load_recipes()
    if all_recipes is None:
        loaded = load_recipes()
        all_recipes = loaded if loaded else dict(recipes)
    unlocked = None
    if save is not None and hasattr(save, "get_unlocked_recipe_ids"):
        unlocked = save.get_unlocked_recipe_ids()
        if unlocked is not None:
            recipes = filter_recipes_by_unlocks(recipes, unlocked)

    # Determine current inventory pool (merging bag + chests or using explicit inventory)
    if inventory is not None:
        current_inventory = {}
        for k, v in inventory.items():
            if not k:
                continue
            try:
                cnt = int(round(float(v)))
                if cnt > 0:
                    k_clean = str(k).strip().lower()
                    current_inventory[k_clean] = current_inventory.get(k_clean, 0) + cnt
            except (ValueError, TypeError):
                pass
    elif save is not None and hasattr(save, "get_all_available_items"):
        current_inventory = {}
        for k, v in save.get_all_available_items().items():
            if not k:
                continue
            try:
                cnt = int(round(float(v)))
                if cnt > 0:
                    k_clean = str(k).strip().lower()
                    current_inventory[k_clean] = current_inventory.get(k_clean, 0) + cnt
            except (ValueError, TypeError):
                pass
    else:
        current_inventory = {}

    initial_inventory = dict(current_inventory)

    is_sat = False
    is_animal_fest = False
    if save is not None and hasattr(save, "in_game_date") and save.in_game_date is not None:
        is_sat = getattr(save.in_game_date, "is_saturday", False)
        is_animal_fest = getattr(save.in_game_date, "is_animal_festival", False)

    planning_for_saturday = (mode in ("saturday", "market")) or (mode == "auto" and is_sat)

    # 1. Determine which NPCs are eligible under current mode
    all_npcs = sorted(npc_gift_definitions.keys())
    target_npcs = set()
    ungiftable_npcs = []
    not_present_npcs = []
    locked_npcs = []
    completed_npcs = []

    npc_progress = {}
    total_game_loved = 0
    total_game_liked = 0
    total_given_loved = 0
    total_given_liked = 0

    for nid in all_npcs:
        if nid in exclude_npcs:
            continue

        g_def = npc_gift_definitions[nid]
        npc_name = g_def.get("name", nid.replace("_", " ").title())
        all_loved = set(g_def.get("loved", []))
        all_liked = set(g_def.get("liked", []))
        is_vendor = nid.lower() in SATURDAY_MARKET_VENDORS

        total_game_loved += len(all_loved)
        total_game_liked += len(all_liked)

        if save is not None and hasattr(save, "get_npc_gifts_given"):
            given_set = save.get_npc_gifts_given(nid)
        else:
            given_set = set()

        given_loved = all_loved & given_set
        given_liked = all_liked & given_set

        total_given_loved += len(given_loved)
        total_given_liked += len(given_liked)

        remaining_loved = all_loved - given_set
        remaining_liked = all_liked - given_set
        is_completed = (len(remaining_loved) == 0 and len(remaining_liked) == 0 and bool(all_loved or all_liked))

        # Check unlocked status from save progression
        is_unlocked = True
        if save is not None and hasattr(save, "is_npc_unlocked") and hasattr(save, "npcs") and save.npcs:
            is_unlocked = save.is_npc_unlocked(nid)

        # Determine presence based on mode
        if not is_unlocked:
            is_present = False
            can_gift = False
            locked_npcs.append(nid)
        else:
            if mode in ("saturday", "market"):
                is_present = True
            elif mode == "market-only":
                is_present = is_vendor
            elif mode in ("townsfolk", "weekday"):
                is_present = not is_vendor
            elif mode == "all":
                is_present = True
            else:  # "auto" or "today"
                is_present = save.is_npc_present_in_town_today(nid) if (save and hasattr(save, "is_npc_present_in_town_today")) else True

            if force_all_npcs:
                can_gift = True
            elif mode in ("saturday", "market") and not is_sat:
                can_gift = True
            elif save is not None and hasattr(save, "can_gift_npc_today"):
                can_gift = save.can_gift_npc_today(nid)
            else:
                can_gift = True

            if is_completed:
                completed_npcs.append(nid)
            elif not is_present:
                not_present_npcs.append(nid)
            elif not can_gift:
                ungiftable_npcs.append(nid)
            elif remaining_loved or remaining_liked:
                target_npcs.add(nid)

        hp = save.get_npc_heart_points(nid) if (save and hasattr(save, "get_npc_heart_points")) else 0.0
        npc_progress[nid] = {
            "name": npc_name,
            "hp": hp,
            "is_vendor": is_vendor,
            "is_unlocked": is_unlocked,
            "is_completed": is_completed,
            "is_present_today": is_present,
            "can_gift_today": can_gift,
            "gifts_given_count": len(given_set),
            "given_loved_count": len(given_loved),
            "given_liked_count": len(given_liked),
            "remaining_loved": remaining_loved,
            "remaining_liked": remaining_liked,
            "remaining_loved_count": len(remaining_loved),
            "remaining_liked_count": len(remaining_liked),
            "total_remaining": len(remaining_loved) + len(remaining_liked),
            "pct_loved_done": (len(given_loved) / len(all_loved) * 100.0) if all_loved else 100.0,
            "pct_total_done": ((len(given_loved) + len(given_liked)) / (len(all_loved) + len(all_liked)) * 100.0) if (all_loved or all_liked) else 100.0,
            "assigned_item_id": None,
            "assigned_item_name": None,
            "assigned_pref_type": None,
        }

    # 2. Build remaining item coverage mapping
    # all_remaining_items_map: All non-excluded NPCs with pending preferences (for focus suggestions and game totals)
    all_remaining_items_map = {}
    for nid, p in npc_progress.items():
        for item_id in p["remaining_loved"]:
            if item_id not in all_remaining_items_map:
                all_remaining_items_map[item_id] = {"loved": set(), "liked": set()}
            all_remaining_items_map[item_id]["loved"].add(nid)

        for item_id in p["remaining_liked"]:
            if item_id not in all_remaining_items_map:
                all_remaining_items_map[item_id] = {"loved": set(), "liked": set()}
            all_remaining_items_map[item_id]["liked"].add(nid)

    # today_remaining_items_map: Items relevant to today's target NPCs (for greedy bag selection)
    today_remaining_items_map = {}
    for nid in target_npcs:
        p = npc_progress[nid]
        for item_id in p["remaining_loved"]:
            if item_id not in today_remaining_items_map:
                today_remaining_items_map[item_id] = {"loved": set(), "liked": set()}
            today_remaining_items_map[item_id]["loved"].add(nid)

        for item_id in p["remaining_liked"]:
            if item_id not in today_remaining_items_map:
                today_remaining_items_map[item_id] = {"loved": set(), "liked": set()}
            today_remaining_items_map[item_id]["liked"].add(nid)

    # 3. Greedy Weighted Set Cover Algorithm with Tiered Availability & Dynamic Pool Deduction
    covered_npcs = set()
    bag_plan = []

    while len(bag_plan) < max_slots and len(covered_npcs) < len(target_npcs):
        best_item_id = None
        best_tuple = None
        best_selected_recipients = []
        best_status_tier = AvailabilityTier.UNAVAILABLE
        best_qty = 0

        for item_id, targets in today_remaining_items_map.items():
            new_loved = (targets["loved"] & target_npcs) - covered_npcs
            new_liked = (targets["liked"] & target_npcs) - covered_npcs

            if not new_loved and not new_liked:
                continue

            max_avail = _calculate_max_craftable(item_id, current_inventory, recipes)
            owned_count = current_inventory.get(item_id, 0)

            # Sort candidate recipients by priority:
            # Loved vendors > Loved townsfolk > Liked vendors > Liked townsfolk
            def recip_sort_key(nid):
                is_v = npc_progress[nid]["is_vendor"]
                is_l = nid in new_loved
                is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                return (0 if is_l and is_boosted else (1 if is_l else (2 if is_boosted else 3)), npc_progress[nid]["name"])

            sorted_recips = sorted(list(new_loved | new_liked), key=recip_sort_key)

            if max_avail > 0:
                actual_cover_count = min(len(sorted_recips), max_avail)
            else:
                actual_cover_count = len(sorted_recips)

            selected_recips = sorted_recips[:actual_cover_count]
            selected_loved = [nid for nid in selected_recips if nid in new_loved]
            selected_liked = [nid for nid in selected_recips if nid in new_liked]

            # Score calculation with Saturday / Festival vendor boost
            score = 0.0
            for nid in selected_loved:
                weight = float(loved_weight)
                is_boosted = (planning_for_saturday and npc_progress[nid]["is_vendor"]) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                if is_boosted:
                    weight *= vendor_boost
                score += weight

            for nid in selected_liked:
                weight = float(liked_weight)
                is_boosted = (planning_for_saturday and npc_progress[nid]["is_vendor"]) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                if is_boosted:
                    weight *= vendor_boost
                score += weight

            if score <= 0:
                continue

            if max_avail <= 0:
                tier = AvailabilityTier.UNAVAILABLE
                tier_rank = 0
            elif owned_count >= actual_cover_count:
                tier = AvailabilityTier.HAVE
                tier_rank = 1
            else:
                tier = AvailabilityTier.CRAFT
                tier_rank = 1

            meta = item_metadata.get(item_id, {})
            try:
                bin_p = int(meta.get("bin_price")) if meta.get("bin_price") not in ("", None) else 999999
            except (ValueError, TypeError):
                bin_p = 999999

            try:
                store_p = int(meta.get("store_price")) if meta.get("store_price") not in ("", None) else 999999
            except (ValueError, TypeError):
                store_p = 999999

            item_name = str(meta.get("display_name", item_id))

            # Count how many visiting / boosted vendors are covered by this item
            vendor_hits = sum(
                1 for nid in selected_recips
                if (planning_for_saturday and npc_progress[nid]["is_vendor"])
                or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
            )

            # 7-element Candidate ranking tuple:
            # (tier_rank, score, vendor_hits, len(selected_loved), -bin_p, -store_p, -len(item_name))
            candidate_tuple = (tier_rank, score, vendor_hits, len(selected_loved), -bin_p, -store_p, -len(item_name))

            if best_item_id is None or candidate_tuple > best_tuple:
                best_tuple = candidate_tuple
                best_item_id = item_id
                best_selected_recipients = selected_recips
                best_status_tier = tier
                best_qty = actual_cover_count

        if best_item_id is None or best_qty <= 0:
            break

        owned = current_inventory.get(best_item_id, 0)
        best_new_loved = [nid for nid in best_selected_recipients if nid in today_remaining_items_map[best_item_id]["loved"]]
        best_new_liked = [nid for nid in best_selected_recipients if nid in today_remaining_items_map[best_item_id]["liked"]]

        meta = item_metadata.get(best_item_id, {})
        disp_name = meta.get("display_name") or best_item_id.replace("_", " ").title()

        # Build list of recipient info
        recipients = []
        for nid in sorted(best_new_loved):
            recipients.append({
                "npc_id": nid,
                "name": npc_progress[nid]["name"],
                "pref": "LOVE",
                "is_vendor": npc_progress[nid]["is_vendor"]
            })
            npc_progress[nid]["assigned_item_id"] = best_item_id
            npc_progress[nid]["assigned_item_name"] = disp_name
            npc_progress[nid]["assigned_pref_type"] = "LOVE"

        for nid in sorted(best_new_liked):
            recipients.append({
                "npc_id": nid,
                "name": npc_progress[nid]["name"],
                "pref": "LIKE",
                "is_vendor": npc_progress[nid]["is_vendor"]
            })
            npc_progress[nid]["assigned_item_id"] = best_item_id
            npc_progress[nid]["assigned_item_name"] = disp_name
            npc_progress[nid]["assigned_pref_type"] = "LIKE"

        quantity_to_pack = best_qty

        # Evaluate craftability and perform dynamic inventory deduction
        plan = evaluate_craftability(best_item_id, current_inventory, recipes, count_needed=quantity_to_pack)
        current_inventory = deduct_crafting_materials(best_item_id, current_inventory, recipes, count=quantity_to_pack)

        # Availability status string and badge
        if best_status_tier == AvailabilityTier.HAVE:
            status_str = "HAVE"
            status_badge = "📦 HAVE"
        elif best_status_tier == AvailabilityTier.CRAFT:
            status_str = "CRAFT"
            if owned > 0:
                status_badge = f"🔨 HAVE ({owned}) + CRAFT ({quantity_to_pack - owned})"
            else:
                status_badge = "✅ CRAFT"
        else:
            status_str = "UNAVAILABLE"
            status_badge = "❌ NEED"

        crafting_chain = plan.chain_summary if plan is not None else ""

        # Also get all potential NPCs who could take this item across all NPCs in the game
        all_potential_loved = sorted([npc_progress[x]["name"] for x in all_remaining_items_map.get(best_item_id, {}).get("loved", set())])
        all_potential_liked = sorted([npc_progress[x]["name"] for x in all_remaining_items_map.get(best_item_id, {}).get("liked", set())])

        tag_list = meta.get("tags", [])
        tags_str = ", ".join(tag_list) if isinstance(tag_list, list) else str(tag_list)

        bag_plan.append({
            "slot": len(bag_plan) + 1,
            "item_id": best_item_id,
            "item_name": disp_name,
            "quantity_to_pack": quantity_to_pack,
            "status": status_str,
            "availability_tier": int(best_status_tier),
            "status_badge": status_badge,
            "crafting_chain": crafting_chain,
            "crafting_plan": plan,
            "max_craftable": plan.max_craftable if plan is not None else 0,
            "raw_materials_needed": plan.raw_materials_needed if plan is not None else {},
            "loved_recipients_today": [r["name"] for r in recipients if r["pref"] == "LOVE"],
            "liked_recipients_today": [r["name"] for r in recipients if r["pref"] == "LIKE"],
            "all_recipients_today": recipients,
            "market_vendors_covered": [r["name"] for r in recipients if r["is_vendor"]],
            "all_potential_loved": all_potential_loved,
            "all_potential_liked": all_potential_liked,
            "bin_price": meta.get("bin_price", ""),
            "store_price": meta.get("store_price", ""),
            "tags": tags_str,
            "description": meta.get("description", "")
        })

        covered_npcs |= set(best_selected_recipients)

    # Overall statistics
    today_loved_count = sum(len(b["loved_recipients_today"]) for b in bag_plan)
    today_liked_count = sum(len(b["liked_recipients_today"]) for b in bag_plan)
    vendors_covered_today = sum(len(b["market_vendors_covered"]) for b in bag_plan)

    if save is not None and hasattr(save, "get_unlocked_npc_ids") and hasattr(save, "npcs") and save.npcs:
        unlocked_vendor_ids = save.get_unlocked_vendor_ids()
        unlocked_townsfolk_ids = {k for k in save.get_unlocked_npc_ids() if k not in SATURDAY_MARKET_VENDORS}
        unlocked_vendors_count = len(unlocked_vendor_ids)
        unlocked_townsfolk_count = len(unlocked_townsfolk_ids)
        unlocked_npcs_count = len(save.get_unlocked_npc_ids())
    else:
        unlocked_npcs_list = [nid for nid, p in npc_progress.items() if p.get("is_unlocked", True)]
        unlocked_vendors = [nid for nid in unlocked_npcs_list if npc_progress[nid]["is_vendor"]]
        unlocked_townsfolk = [nid for nid in unlocked_npcs_list if not npc_progress[nid]["is_vendor"]]
        unlocked_vendors_count = len(unlocked_vendors)
        unlocked_townsfolk_count = len(unlocked_townsfolk)
        unlocked_npcs_count = len(unlocked_npcs_list)

    overall_stats = {
        "mode": mode,
        "planning_for_saturday": planning_for_saturday,
        "is_animal_festival": is_animal_fest,
        "target_npcs_count": len(target_npcs),
        "covered_npcs_count": len(covered_npcs),
        "unlocked_npcs_count": unlocked_npcs_count,
        "unlocked_vendors_count": unlocked_vendors_count,
        "unlocked_townsfolk_count": unlocked_townsfolk_count,
        "slots_used": len(bag_plan),
        "max_slots": max_slots,
        "today_loved_completed": today_loved_count,
        "today_liked_completed": today_liked_count,
        "today_total_completed": today_loved_count + today_liked_count,
        "vendors_covered_today": vendors_covered_today,
        "game_total_loved": total_game_loved,
        "game_total_liked": total_game_liked,
        "game_total_preferences": total_game_loved + total_game_liked,
        "game_given_loved": total_given_loved,
        "game_given_liked": total_given_liked,
        "game_given_total": total_given_loved + total_given_liked,
        "remaining_unique_items": len(all_remaining_items_map),
        "ungiftable_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in ungiftable_npcs if nid in npc_gift_definitions],
        "not_present_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in not_present_npcs if nid in npc_gift_definitions],
        "locked_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in locked_npcs if nid in npc_gift_definitions],
        "completed_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in completed_npcs if nid in npc_gift_definitions],
        "completed_npcs_count": len(completed_npcs),
        "done_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in completed_npcs if nid in npc_gift_definitions],
        "done_npcs_count": len(completed_npcs),
    }

    if all_seasons:
        effective_season = None
    elif current_season is not None:
        effective_season = current_season
    elif save is not None and hasattr(save, "in_game_date") and save.in_game_date is not None:
        effective_season = getattr(save.in_game_date, "season", None)
    else:
        effective_season = None

    overall_stats["current_season"] = effective_season
    overall_stats["all_seasons"] = all_seasons or (effective_season is None)
    overall_stats["seasonal_boost"] = seasonal_boost

    focus_remaining_map = (
        filter_remaining_items_for_focus(all_remaining_items_map, focus_npcs)
        if (focus_mode_enabled and focus_npcs)
        else all_remaining_items_map
    )

    focus_suggestions = compute_focus_suggestions(
        remaining_items_map=all_remaining_items_map,
        inventory=initial_inventory,
        recipes=all_recipes,
        item_metadata=item_metadata,
        top_n=focus_top_n,
        item_locations=item_locations,
        focus_sort=focus_sort,
        current_season=effective_season,
        item_seasons=item_seasons,
        seasonal_boost=seasonal_boost,
        focus_mode_enabled=focus_mode_enabled,
        focus_npcs=focus_npcs,
    )

    all_unobtained_recipes, recipe_unlock_stats = compute_focus_recipes(
        all_recipes=all_recipes,
        unlocked_recipe_ids=unlocked if (save is not None) else None,
        remaining_items_map=all_remaining_items_map,
        recipe_sources=recipe_sources,
        top_n=None,
    )
    focus_recipes = all_unobtained_recipes[:10]

    alt_sources_data = load_alt_sources() if alt_sources is None else alt_sources

    npc_names_map = {
        nid.lower(): data.get("name", nid.capitalize())
        for nid, data in npc_gift_definitions.items()
        if isinstance(data, dict)
    }

    focus_trees = build_focus_crafting_trees(
        focus_suggestions=focus_suggestions,
        recipes=all_recipes,
        remaining_items_map=focus_remaining_map,
        alt_sources=alt_sources_data,
        item_metadata=item_metadata,
        npc_names=npc_names_map,
    )

    source_priority = compute_source_priorities(
        focus_suggestions=focus_suggestions,
        item_locations=item_locations,
        alt_sources=alt_sources_data,
        npc_names=npc_names_map,
    )

    return {
        "bag_plan": bag_plan,
        "npc_progress": npc_progress,
        "covered_npcs": covered_npcs,
        "target_npcs": target_npcs,
        "remaining_items_map": all_remaining_items_map,
        "all_remaining_items_map": all_remaining_items_map,
        "today_remaining_items_map": today_remaining_items_map,
        "focus_suggestions": focus_suggestions,
        "focus_recipes": focus_recipes,
        "all_unobtained_recipes": all_unobtained_recipes,
        "recipe_unlock_stats": recipe_unlock_stats,
        "focus_trees": focus_trees,
        "source_priority": source_priority,
        "alt_sources": alt_sources_data,
        "focus_sort": focus_sort,
        "current_season": effective_season,
        "all_seasons": all_seasons or (effective_season is None),
        "seasonal_boost": seasonal_boost,
        "overall_stats": overall_stats,
    }


def _normalize_infused_pool(infused_data: Any, infusion_key: str) -> Dict[str, int]:
    """
    Defensively normalizes arbitrary infused item structures into a {item_id: count} mapping.

    Supports:
      1. R1 SaveData format: {"lovable": [{"item_id": ..., "count": ...}], ...}
      2. Dict mapping: {"lovable": {"apple_pie": 2}, ...}
      3. Iterables of strings: {"lovable": ["apple_pie", "berry_tart"], ...}
      4. Flat list of slot dicts: [{"item": {"item_id": ..., "infusion": ...}, "count": ...}, ...]
      5. Flat list of item dicts: [{"item_id": ..., "infusion": ..., "count": ...}, ...]
    """
    if not infused_data:
        return {}

    pool: Dict[str, int] = {}
    target_infusions = {"lovable"} if infusion_key == "lovable" else {"likable", "likeable"}

    raw_entries: List[Any] = []
    if isinstance(infused_data, dict):
        val = infused_data.get(infusion_key)
        if val is None and infusion_key == "likable":
            val = infused_data.get("likeable")
        elif val is None and infusion_key == "likeable":
            val = infused_data.get("likable")

        if isinstance(val, dict):
            for k, cnt_val in val.items():
                if not k:
                    continue
                k_clean = str(k).strip().lower()
                try:
                    cnt = int(round(float(cnt_val)))
                    if cnt > 0:
                        pool[k_clean] = pool.get(k_clean, 0) + cnt
                except (ValueError, TypeError, OverflowError):
                    pass
            return pool
        elif isinstance(val, (list, tuple, set)):
            raw_entries = list(val)
        elif val is not None:
            raw_entries = [val]
    elif isinstance(infused_data, (list, tuple, set)):
        for entry in infused_data:
            if not isinstance(entry, dict):
                continue
            sub_item = entry.get("item")
            if isinstance(sub_item, dict):
                inf = str(sub_item.get("infusion") or "").strip().lower()
                if inf in target_infusions:
                    raw_entries.append({
                        "item_id": sub_item.get("item_id"),
                        "count": entry.get("count", 1),
                    })
            else:
                inf = str(entry.get("infusion") or "").strip().lower()
                if inf in target_infusions:
                    raw_entries.append(entry)
    else:
        return {}

    for item in raw_entries:
        if isinstance(item, dict):
            iid_raw = item.get("item_id")
            if not iid_raw:
                continue
            iid = str(iid_raw).strip().lower()
            try:
                cnt = int(round(float(item.get("count", 1))))
            except (ValueError, TypeError, OverflowError):
                cnt = 1
            if iid and cnt > 0:
                pool[iid] = pool.get(iid, 0) + cnt
        elif isinstance(item, (str, bytes)):
            iid = str(item).strip().lower()
            if iid:
                pool[iid] = pool.get(iid, 0) + 1

    return pool


def plan_max_relationship(
    save: Optional[SaveData] = None,
    npc_gift_definitions: Optional[Dict[str, dict]] = None,
    item_metadata: Optional[Dict[str, dict]] = None,
    mode: str = "auto",
    max_slots: int = 20,
    exclude_npcs: Optional[Union[Set[str], List[str]]] = None,
    force_all_npcs: bool = False,
    inventory: Optional[Dict[str, int]] = None,
    infused_items: Optional[Any] = None,
    recipes: Optional[Dict[str, Any]] = None,
    all_recipes: Optional[Dict[str, Any]] = None,
    item_locations: Optional[Dict[str, str]] = None,
    max_relationship_points: Optional[float] = None,
    exclude_max_relationship: bool = True,
    focus_sort: str = "impact",
    recipe_sources: Optional[Dict[str, str]] = None,
    current_season: Optional[str] = None,
    item_seasons: Optional[Dict[str, List[str]]] = None,
    all_seasons: bool = False,
    seasonal_boost: float = 2.0,
    focus_top_n: int = 20,
    alt_sources: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    focus_mode_enabled: bool = False,
    focus_npcs: Optional[Union[Set[str], List[str], str]] = None,
) -> dict:
    """
    Computes a daily gift assignment to maximize total relationship points earned today.

    Game Mechanics & Relationship Points:
      Standard Daily Gifting (no birthday multiplier):
        - Love Gift:              +20 points
        - Universal Love Gift:    +20 points (infused with 'lovable')
        - Like Gift:              +10 points
        - Universal Like Gift:    +10 points (infused with 'likable')
        - Neutral Gift:           +3 points (omitted to preserve bag slots)
        - Dislike / Hate:         +0 points (omitted)

    Optimization Algorithm:
      1. Strict 5-tier Priority Hierarchy:
           Specific Love (+20) > Universal Love (+20) > Specific Like (+10) > Universal Like (+10) > Skip (+0)
         Specific gifts are strictly prioritized over universal gifts within the same point tier
         to preserve globally fungible universal infusion dishes for NPCs lacking specific gifts.
      2. Greedy Constrained Allocation (MRV - Minimum Remaining Values):
         NPCs with the fewest available specific candidates in inventory are allocated first.
         This prevents flexible NPCs with broad tastes from consuming items needed by constrained NPCs.
      3. Abundance Tie-breaking:
         When multiple eligible gifts are available for an NPC within a tier, the item with the
         highest current inventory count is chosen, preserving rarer items.
         Deterministic tie-breaking is enforced by display name and item ID.
      4. Exact Inventory Deduction & Infusion Synchronization:
         Physical inventory is decremented immediately upon each assignment.
         Infusion pools and physical inventory are synchronized bidirectionally to guarantee that
         an item stack cannot be double-spent across specific and universal allocations.
      5. NPC Presence & Festival Logic:
         Respects day-of-week, Saturday Market vendor availability, Animal Festival (Winter 10),
         and progression lock states (e.g. story-gated NPCs and market expansion vendors).
      6. Capacity Budgeting:
         If the number of distinct items packed exceeds max_slots, items are ranked by total
         points delivered, vendor coverage, recipient count, and name. Slots beyond max_slots
         are cleanly truncated and their NPC assignments rolled back.

    Parameters:
      save: Parsed SaveData instance containing calendar, NPC presence, and inventory states.
      npc_gift_definitions: Mapping of NPC IDs to preference dicts (with 'loved' and 'liked' sets).
      item_metadata: Metadata database for display names, prices, tags, descriptions.
      mode: Target planning mode ('auto', 'saturday', 'market-only', 'townsfolk', 'all').
      max_slots: Maximum bag slots allocated for daily gifts (default: 20).
      exclude_npcs: Set or list of NPC IDs to exclude from daily gifting.
      force_all_npcs: If True, bypasses can_gift_npc_today daily gift flag.
      inventory: Optional explicit inventory dict {item_id: count} overriding save data.
      infused_items: Optional explicit infused dishes structure overriding auto-detection.
      recipes: Recipe dictionary for computing downstream blocker focus suggestions.
      item_locations: Mapping of item IDs to world acquisition hints.
      recipe_sources: Mapping of recipe ID to unlock source string.

    Returns:
      A dictionary compatible with all exporters (terminal, CSV, Excel):
        - bag_plan: Ordered list of packed item dictionaries up to max_slots.
        - npc_progress: Progress, assignment, and points per NPC.
        - covered_npcs: Set of NPC IDs assigned a gift today.
        - target_npcs: Set of present, eligible NPC IDs targeted today.
        - remaining_items_map: Downstream mapping of pending items for Excel Sheet 3.
        - all_remaining_items_map: All pending items across all non-excluded NPCs.
        - today_remaining_items_map: Pending items relevant to today's target NPCs.
        - focus_suggestions: List of blocker raw material deficit suggestions.
        - focus_recipes: Top ranked locked cooking recipes by impact.
        - recipe_unlock_stats: Summary statistics of cooking recipe unlocks.
        - overall_stats: Comprehensive summary statistics including total_relationship_points.
        - infused_items: Raw or detected infused items pool.
    """
    # 1. Normalize exclude_npcs
    clean_excluded: Set[str] = set()
    if exclude_npcs is not None:
        if isinstance(exclude_npcs, (set, list, tuple)):
            clean_excluded = {str(x).strip().lower() for x in exclude_npcs if x and str(x).strip()}
        elif isinstance(exclude_npcs, (str, bytes)):
            s = str(exclude_npcs).strip().lower()
            if s:
                clean_excluded = {s}

    if npc_gift_definitions is None:
        npc_gift_definitions = {}
    if item_metadata is None:
        item_metadata = {}
    if recipes is None:
        recipes = load_recipes()
    if all_recipes is None:
        loaded = load_recipes()
        all_recipes = loaded if loaded else dict(recipes)
    unlocked = None
    if save is not None and hasattr(save, "get_unlocked_recipe_ids"):
        unlocked = save.get_unlocked_recipe_ids()
        if unlocked is not None:
            recipes = filter_recipes_by_unlocks(recipes, unlocked)
    if item_locations is None:
        item_locations = ITEM_LOCATIONS

    # 2. Resolve Regular Inventory Pool
    current_inventory: Dict[str, int] = {}
    if inventory is not None:
        if isinstance(inventory, dict):
            for k, v in inventory.items():
                if not k:
                    continue
                try:
                    cnt = int(round(float(v)))
                    if cnt > 0:
                        k_clean = str(k).strip().lower()
                        current_inventory[k_clean] = current_inventory.get(k_clean, 0) + cnt
                except (ValueError, TypeError, OverflowError):
                    pass
    elif save is not None and hasattr(save, "get_all_available_items"):
        try:
            raw_items = save.get_all_available_items()
            if isinstance(raw_items, dict):
                for k, v in raw_items.items():
                    if not k:
                        continue
                    try:
                        cnt = int(round(float(v)))
                        if cnt > 0:
                            k_clean = str(k).strip().lower()
                            current_inventory[k_clean] = current_inventory.get(k_clean, 0) + cnt
                    except (ValueError, TypeError, OverflowError):
                        pass
        except Exception:
            current_inventory = {}

    initial_inventory = dict(current_inventory)

    # 3. Resolve Infused Items Pool
    if infused_items is None and save is not None and hasattr(save, "get_infused_items"):
        try:
            raw_infused = save.get_infused_items()
        except Exception:
            raw_infused = None
    else:
        raw_infused = infused_items

    lovable_pool = _normalize_infused_pool(raw_infused, "lovable")
    likable_pool = _normalize_infused_pool(raw_infused, "likable")
    total_infused_detected = sum(lovable_pool.values()) + sum(likable_pool.values())

    # 4. Calendar, Festival & Saturday Awareness
    is_sat = False
    is_animal_fest = False
    if save is not None and hasattr(save, "in_game_date") and save.in_game_date is not None:
        is_sat = bool(getattr(save.in_game_date, "is_saturday", False))
        is_animal_fest = bool(getattr(save.in_game_date, "is_animal_festival", False))

    planning_for_saturday = (mode in ("saturday", "market")) or (mode == "auto" and is_sat)

    # 5. Filter and Classify Target NPCs
    all_npcs = sorted(npc_gift_definitions.keys())
    target_npcs: Set[str] = set()
    ungiftable_npcs: List[str] = []
    not_present_npcs: List[str] = []
    locked_npcs: List[str] = []
    max_relationship_npcs: List[str] = []
    completed_npcs: List[str] = []

    npc_progress: Dict[str, dict] = {}
    total_game_loved = 0
    total_game_liked = 0
    total_given_loved = 0
    total_given_liked = 0

    for nid in all_npcs:
        nid_clean = str(nid).strip().lower()
        if nid_clean in clean_excluded:
            continue

        g_def = npc_gift_definitions[nid]
        npc_name = str(g_def.get("name") or nid.replace("_", " ").title())
        all_loved = {str(x).strip().lower() for x in (g_def.get("loved") or []) if x}
        all_liked = {str(x).strip().lower() for x in (g_def.get("liked") or []) if x}
        is_vendor = nid_clean in SATURDAY_MARKET_VENDORS

        total_game_loved += len(all_loved)
        total_game_liked += len(all_liked)

        if save is not None and hasattr(save, "get_npc_gifts_given"):
            try:
                raw_given = save.get_npc_gifts_given(nid)
                given_set = {str(x).strip().lower() for x in (raw_given or []) if x}
            except Exception:
                given_set = set()
        else:
            given_set = set()

        given_loved = all_loved & given_set
        given_liked = all_liked & given_set
        total_given_loved += len(given_loved)
        total_given_liked += len(given_liked)

        remaining_loved = all_loved - given_set
        remaining_liked = all_liked - given_set
        is_completed = (len(remaining_loved) == 0 and len(remaining_liked) == 0 and bool(all_loved or all_liked))

        hp = 0.0
        if save is not None and hasattr(save, "get_npc_heart_points"):
            try:
                hp = float(save.get_npc_heart_points(nid_clean))
            except (ValueError, TypeError):
                hp = 0.0

        is_max_rel = False
        if exclude_max_relationship:
            if save is not None and hasattr(save, "is_npc_max_relationship"):
                try:
                    is_max_rel = bool(save.is_npc_max_relationship(nid_clean, max_points=max_relationship_points))
                except Exception:
                    is_max_rel = False
            elif max_relationship_points is not None:
                is_max_rel = (hp >= max_relationship_points)

        is_unlocked = True
        if save is not None and hasattr(save, "is_npc_unlocked") and hasattr(save, "npcs") and save.npcs:
            try:
                is_unlocked = bool(save.is_npc_unlocked(nid_clean))
            except Exception:
                is_unlocked = True

        if is_completed and is_unlocked:
            completed_npcs.append(nid)

        if not is_unlocked:
            is_present = False
            can_gift = False
            locked_npcs.append(nid)
        elif is_max_rel:
            if mode in ("saturday", "market"):
                is_present = True
            elif mode == "market-only":
                is_present = is_vendor
            elif mode in ("townsfolk", "weekday"):
                is_present = not is_vendor
            elif mode == "all":
                is_present = True
            else:  # "auto" or "today"
                if save is not None and hasattr(save, "is_npc_present_in_town_today"):
                    is_present = bool(save.is_npc_present_in_town_today(nid_clean))
                else:
                    is_present = True

            can_gift = False
            max_relationship_npcs.append(nid)
        else:
            if mode in ("saturday", "market"):
                is_present = True
            elif mode == "market-only":
                is_present = is_vendor
            elif mode in ("townsfolk", "weekday"):
                is_present = not is_vendor
            elif mode == "all":
                is_present = True
            else:  # "auto" or "today"
                if save is not None and hasattr(save, "is_npc_present_in_town_today"):
                    is_present = bool(save.is_npc_present_in_town_today(nid_clean))
                else:
                    is_present = True

            if force_all_npcs:
                can_gift = True
            elif mode in ("saturday", "market") and not is_sat:
                can_gift = True
            elif save is not None and hasattr(save, "can_gift_npc_today"):
                try:
                    can_gift = bool(save.can_gift_npc_today(nid_clean))
                except Exception:
                    can_gift = True
            else:
                can_gift = True

            if not is_present:
                not_present_npcs.append(nid)
            elif not can_gift:
                ungiftable_npcs.append(nid)
            else:
                target_npcs.add(nid)

        npc_progress[nid] = {
            "name": npc_name,
            "hp": hp,
            "is_vendor": is_vendor,
            "is_unlocked": is_unlocked,
            "is_completed": is_completed,
            "is_max_relationship": is_max_rel,
            "is_present_today": is_present,
            "can_gift_today": can_gift,
            "loved": all_loved,
            "liked": all_liked,
            "gifts_given_count": len(given_set),
            "given_loved_count": len(given_loved),
            "given_liked_count": len(given_liked),
            "remaining_loved": remaining_loved,
            "remaining_liked": remaining_liked,
            "remaining_loved_count": len(remaining_loved),
            "remaining_liked_count": len(remaining_liked),
            "total_remaining": len(remaining_loved) + len(remaining_liked),
            "pct_loved_done": (len(given_loved) / len(all_loved) * 100.0) if all_loved else 100.0,
            "pct_total_done": ((len(given_loved) + len(given_liked)) / (len(all_loved) + len(all_liked)) * 100.0) if (all_loved or all_liked) else 100.0,
            "assigned_item_id": None,
            "assigned_item_name": None,
            "assigned_pref_type": None,
            "assigned_points": 0,
        }

    # 6. Build remaining item coverage mappings for downstream tools
    all_remaining_items_map: Dict[str, dict] = {}
    for nid, p in npc_progress.items():
        for iid in p["remaining_loved"]:
            if iid not in all_remaining_items_map:
                all_remaining_items_map[iid] = {"loved": set(), "liked": set()}
            all_remaining_items_map[iid]["loved"].add(nid)
        for iid in p["remaining_liked"]:
            if iid not in all_remaining_items_map:
                all_remaining_items_map[iid] = {"loved": set(), "liked": set()}
            all_remaining_items_map[iid]["liked"].add(nid)

    today_remaining_items_map: Dict[str, dict] = {}
    for nid in target_npcs:
        p = npc_progress[nid]
        for iid in p["remaining_loved"]:
            if iid not in today_remaining_items_map:
                today_remaining_items_map[iid] = {"loved": set(), "liked": set()}
            today_remaining_items_map[iid]["loved"].add(nid)
        for iid in p["remaining_liked"]:
            if iid not in today_remaining_items_map:
                today_remaining_items_map[iid] = {"loved": set(), "liked": set()}
            today_remaining_items_map[iid]["liked"].add(nid)

    # 7. Allocation Pipeline: Priority Hierarchy with MRV and Abundance Tie-breaking
    unassigned_npcs = set(target_npcs)
    crafted_assignments: Set[str] = set()

    def _sync_deduct_specific(item_id: str):
        current_inventory[item_id] -= 1
        rem = current_inventory[item_id]
        if rem <= 0:
            del current_inventory[item_id]

        if item_id in lovable_pool and lovable_pool[item_id] > rem:
            if rem <= 0:
                del lovable_pool[item_id]
            else:
                lovable_pool[item_id] = rem

        if item_id in likable_pool and likable_pool[item_id] > rem:
            if rem <= 0:
                del likable_pool[item_id]
            else:
                likable_pool[item_id] = rem

    def _sync_after_craft(chosen_item: str):
        for pool in (lovable_pool, likable_pool):
            for k in list(pool.keys()):
                cur = current_inventory.get(k, 0)
                if cur <= 0:
                    del pool[k]
                elif pool[k] > cur:
                    pool[k] = cur

    def _sync_deduct_universal(item_id: str, pool: Dict[str, int], other_pool: Optional[Dict[str, int]] = None):
        pool[item_id] -= 1
        if pool[item_id] <= 0:
            del pool[item_id]

        if item_id in current_inventory:
            current_inventory[item_id] -= 1
            rem = current_inventory[item_id]
            if rem <= 0:
                del current_inventory[item_id]

            if other_pool is not None and item_id in other_pool and other_pool[item_id] > rem:
                if rem <= 0:
                    del other_pool[item_id]
                else:
                    other_pool[item_id] = rem

    # Stage 1: Specific Love Gifts (+20) (Owned then Crafted)
    def _allocate_loved_owned():
        while True:
            candidates = []
            for nid in unassigned_npcs:
                avail = [iid for iid in npc_progress[nid]["loved"] if current_inventory.get(iid, 0) > 0]
                if avail:
                    is_v = npc_progress[nid]["is_vendor"]
                    is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                    candidates.append((
                        len(avail),
                        0 if is_boosted else 1,
                        str(npc_progress[nid]["name"]).lower(),
                        nid,
                        avail,
                    ))
            if not candidates:
                break

            candidates.sort(key=lambda x: (x[0], x[1], x[2], x[3]))
            _, _, _, best_nid, avail = candidates[0]

            avail.sort(key=lambda iid: (
                -current_inventory.get(iid, 0),
                str(item_metadata.get(iid, {}).get("display_name") or iid).lower(),
                iid,
            ))
            chosen_item = avail[0]

            _sync_deduct_specific(chosen_item)

            meta = item_metadata.get(chosen_item, {})
            disp_name = str(meta.get("display_name") or chosen_item.replace("_", " ").title())

            npc_progress[best_nid]["assigned_item_id"] = chosen_item
            npc_progress[best_nid]["assigned_item_name"] = disp_name
            npc_progress[best_nid]["assigned_pref_type"] = "LOVE"
            npc_progress[best_nid]["assigned_points"] = 20
            unassigned_npcs.remove(best_nid)

    def _allocate_loved_crafted():
        nonlocal current_inventory
        if not recipes:
            return
        while True:
            candidates = []
            for nid in unassigned_npcs:
                craftable_avail = [
                    iid for iid in npc_progress[nid]["loved"]
                    if _calculate_max_craftable(iid, current_inventory, recipes) > 0
                ]
                if craftable_avail:
                    is_v = npc_progress[nid]["is_vendor"]
                    is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                    candidates.append((
                        len(craftable_avail),
                        0 if is_boosted else 1,
                        str(npc_progress[nid]["name"]).lower(),
                        nid,
                        craftable_avail,
                    ))
            if not candidates:
                break

            candidates.sort(key=lambda x: (x[0], x[1], x[2], x[3]))
            _, _, _, best_nid, craftable_avail = candidates[0]

            craftable_avail.sort(key=lambda iid: (
                -_calculate_max_craftable(iid, current_inventory, recipes),
                str(item_metadata.get(iid, {}).get("display_name") or iid).lower(),
                iid,
            ))
            chosen_item = craftable_avail[0]

            current_inventory = deduct_crafting_materials(chosen_item, current_inventory, recipes, count=1)
            _sync_after_craft(chosen_item)

            meta = item_metadata.get(chosen_item, {})
            disp_name = str(meta.get("display_name") or chosen_item.replace("_", " ").title())

            npc_progress[best_nid]["assigned_item_id"] = chosen_item
            npc_progress[best_nid]["assigned_item_name"] = disp_name
            npc_progress[best_nid]["assigned_pref_type"] = "LOVE"
            npc_progress[best_nid]["assigned_points"] = 20
            crafted_assignments.add(best_nid)
            unassigned_npcs.remove(best_nid)

    _allocate_loved_owned()
    _allocate_loved_crafted()

    # Stage 2: Universal Love Gifts (+20)
    if lovable_pool:
        def univ_love_sort_key(nid):
            avail_likes = sum(1 for iid in npc_progress[nid]["liked"] if current_inventory.get(iid, 0) > 0)
            is_v = npc_progress[nid]["is_vendor"]
            is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
            return (0 if is_boosted else 1, avail_likes, str(npc_progress[nid]["name"]).lower(), nid)

        sorted_unassigned = sorted(list(unassigned_npcs), key=univ_love_sort_key)
        for nid in sorted_unassigned:
            if not lovable_pool:
                break
            avail_lovable = sorted(
                list(lovable_pool.keys()),
                key=lambda iid: (
                    -lovable_pool[iid],
                    str(item_metadata.get(iid, {}).get("display_name") or iid).lower(),
                    iid,
                ),
            )
            chosen_item = avail_lovable[0]
            _sync_deduct_universal(chosen_item, lovable_pool, likable_pool)

            meta = item_metadata.get(chosen_item, {})
            disp_name = str(meta.get("display_name") or chosen_item.replace("_", " ").title())

            npc_progress[nid]["assigned_item_id"] = chosen_item
            npc_progress[nid]["assigned_item_name"] = disp_name
            npc_progress[nid]["assigned_pref_type"] = "UNIV_LOVE"
            npc_progress[nid]["assigned_points"] = 20
            unassigned_npcs.remove(nid)

    # Stage 3: Specific Like Gifts (+10) (Owned then Crafted)
    def _allocate_liked_owned():
        while True:
            candidates = []
            for nid in unassigned_npcs:
                avail = [iid for iid in npc_progress[nid]["liked"] if current_inventory.get(iid, 0) > 0]
                if avail:
                    is_v = npc_progress[nid]["is_vendor"]
                    is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                    candidates.append((
                        len(avail),
                        0 if is_boosted else 1,
                        str(npc_progress[nid]["name"]).lower(),
                        nid,
                        avail,
                    ))
            if not candidates:
                break

            candidates.sort(key=lambda x: (x[0], x[1], x[2], x[3]))
            _, _, _, best_nid, avail = candidates[0]

            avail.sort(key=lambda iid: (
                -current_inventory.get(iid, 0),
                str(item_metadata.get(iid, {}).get("display_name") or iid).lower(),
                iid,
            ))
            chosen_item = avail[0]

            _sync_deduct_specific(chosen_item)

            meta = item_metadata.get(chosen_item, {})
            disp_name = str(meta.get("display_name") or chosen_item.replace("_", " ").title())

            npc_progress[best_nid]["assigned_item_id"] = chosen_item
            npc_progress[best_nid]["assigned_item_name"] = disp_name
            npc_progress[best_nid]["assigned_pref_type"] = "LIKE"
            npc_progress[best_nid]["assigned_points"] = 10
            unassigned_npcs.remove(best_nid)

    def _allocate_liked_crafted():
        nonlocal current_inventory
        if not recipes:
            return
        while True:
            candidates = []
            for nid in unassigned_npcs:
                craftable_avail = [
                    iid for iid in npc_progress[nid]["liked"]
                    if _calculate_max_craftable(iid, current_inventory, recipes) > 0
                ]
                if craftable_avail:
                    is_v = npc_progress[nid]["is_vendor"]
                    is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
                    candidates.append((
                        len(craftable_avail),
                        0 if is_boosted else 1,
                        str(npc_progress[nid]["name"]).lower(),
                        nid,
                        craftable_avail,
                    ))
            if not candidates:
                break

            candidates.sort(key=lambda x: (x[0], x[1], x[2], x[3]))
            _, _, _, best_nid, craftable_avail = candidates[0]

            craftable_avail.sort(key=lambda iid: (
                -_calculate_max_craftable(iid, current_inventory, recipes),
                str(item_metadata.get(iid, {}).get("display_name") or iid).lower(),
                iid,
            ))
            chosen_item = craftable_avail[0]

            current_inventory = deduct_crafting_materials(chosen_item, current_inventory, recipes, count=1)
            _sync_after_craft(chosen_item)

            meta = item_metadata.get(chosen_item, {})
            disp_name = str(meta.get("display_name") or chosen_item.replace("_", " ").title())

            npc_progress[best_nid]["assigned_item_id"] = chosen_item
            npc_progress[best_nid]["assigned_item_name"] = disp_name
            npc_progress[best_nid]["assigned_pref_type"] = "LIKE"
            npc_progress[best_nid]["assigned_points"] = 10
            crafted_assignments.add(best_nid)
            unassigned_npcs.remove(best_nid)

    _allocate_liked_owned()
    _allocate_liked_crafted()

    # Stage 4: Universal Like Gifts (+10)
    if likable_pool:
        def univ_like_sort_key(nid):
            is_v = npc_progress[nid]["is_vendor"]
            is_boosted = (planning_for_saturday and is_v) or (is_animal_fest and nid.lower() in ANIMAL_FESTIVAL_ATTENDING_VENDORS)
            return (0 if is_boosted else 1, str(npc_progress[nid]["name"]).lower(), nid)

        sorted_unassigned = sorted(list(unassigned_npcs), key=univ_like_sort_key)
        for nid in sorted_unassigned:
            if not likable_pool:
                break
            avail_likable = sorted(
                list(likable_pool.keys()),
                key=lambda iid: (
                    -likable_pool[iid],
                    str(item_metadata.get(iid, {}).get("display_name") or iid).lower(),
                    iid,
                ),
            )
            chosen_item = avail_likable[0]
            _sync_deduct_universal(chosen_item, likable_pool, lovable_pool)

            meta = item_metadata.get(chosen_item, {})
            disp_name = str(meta.get("display_name") or chosen_item.replace("_", " ").title())

            npc_progress[nid]["assigned_item_id"] = chosen_item
            npc_progress[nid]["assigned_item_name"] = disp_name
            npc_progress[nid]["assigned_pref_type"] = "UNIV_LIKE"
            npc_progress[nid]["assigned_points"] = 10
            unassigned_npcs.remove(nid)

    # Stage 5: Skip (remaining NPCs in unassigned_npcs get 0 points)

    # 8. Aggregate Assigned Items into Bag Plan Slots
    items_to_recipients: Dict[str, List[dict]] = {}
    for nid in target_npcs:
        p = npc_progress[nid]
        item_id = p.get("assigned_item_id")
        if item_id:
            if item_id not in items_to_recipients:
                items_to_recipients[item_id] = []
            items_to_recipients[item_id].append({
                "npc_id": nid,
                "name": p["name"],
                "pref": p["assigned_pref_type"],
                "pref_tier": p["assigned_pref_type"],
                "is_vendor": p["is_vendor"],
                "points": p["assigned_points"],
            })

    def _item_pack_sort_key(iid: str):
        recips = items_to_recipients[iid]
        tot_pts = sum(r["points"] for r in recips)
        vendor_hits = sum(1 for r in recips if r["is_vendor"])
        meta = item_metadata.get(iid, {})
        disp_name = str(meta.get("display_name") or iid).lower()
        return (-tot_pts, -vendor_hits, -len(recips), disp_name, iid)

    sorted_items = sorted(items_to_recipients.keys(), key=_item_pack_sort_key)

    effective_max_slots = max(0, int(max_slots))
    packed_items = sorted_items[:effective_max_slots]
    reverted_items = set(sorted_items[effective_max_slots:])

    for rev_iid in reverted_items:
        for r in items_to_recipients[rev_iid]:
            rev_nid = r["npc_id"]
            npc_progress[rev_nid]["assigned_item_id"] = None
            npc_progress[rev_nid]["assigned_item_name"] = None
            npc_progress[rev_nid]["assigned_pref_type"] = None
            npc_progress[rev_nid]["assigned_points"] = 0

    covered_npcs: Set[str] = set()
    bag_plan: List[Dict[str, Any]] = []

    for slot_num, iid in enumerate(packed_items, start=1):
        recipients = items_to_recipients[iid]
        meta = item_metadata.get(iid, {})
        disp_name = str(meta.get("display_name") or iid.replace("_", " ").title())
        tag_list = meta.get("tags", [])
        tags_str = ", ".join(tag_list) if isinstance(tag_list, list) else str(tag_list)

        loved_recips = [r["name"] for r in recipients if r["pref"] in ("LOVE", "UNIV_LOVE")]
        liked_recips = [r["name"] for r in recipients if r["pref"] in ("LIKE", "UNIV_LIKE")]
        vendor_recips = [r["name"] for r in recipients if r["is_vendor"]]

        all_pot_loved = sorted([npc_progress[x]["name"] for x in all_remaining_items_map.get(iid, {}).get("loved", set()) if x in npc_progress])
        all_pot_liked = sorted([npc_progress[x]["name"] for x in all_remaining_items_map.get(iid, {}).get("liked", set()) if x in npc_progress])

        crafted_count = sum(1 for r in recipients if r["npc_id"] in crafted_assignments)
        total_qty = len(recipients)
        owned_count = total_qty - crafted_count

        if crafted_count == 0:
            status_str = "HAVE"
            tier = AvailabilityTier.HAVE
            status_badge = "📦 HAVE"
            crafting_chain = ""
            plan = None
            max_craft = 0
            raw_mats = {}
        else:
            status_str = "CRAFT"
            tier = AvailabilityTier.CRAFT
            if owned_count > 0:
                status_badge = f"🔨 HAVE ({owned_count}) + CRAFT ({crafted_count})"
            else:
                status_badge = "🔨 CRAFT"

            plan = evaluate_craftability(iid, initial_inventory, recipes, count_needed=total_qty)
            crafting_chain = plan.chain_summary if plan is not None else ""
            max_craft = plan.max_craftable if plan is not None else 0
            raw_mats = plan.raw_materials_needed if plan is not None else {}

        bag_plan.append({
            "slot": slot_num,
            "item_id": iid,
            "item_name": disp_name,
            "quantity_to_pack": total_qty,
            "status": status_str,
            "availability_tier": int(tier),
            "status_badge": status_badge,
            "crafting_chain": crafting_chain,
            "crafting_plan": plan,
            "max_craftable": max_craft,
            "raw_materials_needed": raw_mats,
            "loved_recipients_today": loved_recips,
            "liked_recipients_today": liked_recips,
            "all_recipients_today": recipients,
            "market_vendors_covered": vendor_recips,
            "all_potential_loved": all_pot_loved,
            "all_potential_liked": all_pot_liked,
            "bin_price": meta.get("bin_price", ""),
            "store_price": meta.get("store_price", ""),
            "tags": tags_str,
            "description": meta.get("description", ""),
        })
        covered_npcs.update(r["npc_id"] for r in recipients)

    # 9. Compute Overall Statistics & Total Points
    today_loved_count = sum(len(b["loved_recipients_today"]) for b in bag_plan)
    today_liked_count = sum(len(b["liked_recipients_today"]) for b in bag_plan)
    vendors_covered_today = sum(len(b["market_vendors_covered"]) for b in bag_plan)
    total_relationship_points = sum(
        p["assigned_points"] for p in npc_progress.values() if p.get("assigned_item_id")
    )

    if save is not None and hasattr(save, "get_unlocked_npc_ids") and hasattr(save, "npcs") and save.npcs:
        try:
            unlocked_vendor_ids = save.get_unlocked_vendor_ids()
            unlocked_townsfolk_ids = {k for k in save.get_unlocked_npc_ids() if k not in SATURDAY_MARKET_VENDORS}
            unlocked_vendors_count = len(unlocked_vendor_ids)
            unlocked_townsfolk_count = len(unlocked_townsfolk_ids)
            unlocked_npcs_count = len(save.get_unlocked_npc_ids())
        except Exception:
            unlocked_vendors_count = 0
            unlocked_townsfolk_count = 0
            unlocked_npcs_count = 0
    else:
        unlocked_npcs_list = [nid for nid, p in npc_progress.items() if p.get("is_unlocked", True)]
        unlocked_vendors = [nid for nid in unlocked_npcs_list if npc_progress[nid]["is_vendor"]]
        unlocked_townsfolk = [nid for nid in unlocked_npcs_list if not npc_progress[nid]["is_vendor"]]
        unlocked_vendors_count = len(unlocked_vendors)
        unlocked_townsfolk_count = len(unlocked_townsfolk)
        unlocked_npcs_count = len(unlocked_npcs_list)

    overall_stats = {
        "strategy": "max-relationship",
        "total_relationship_points": total_relationship_points,
        "mode": mode,
        "planning_for_saturday": planning_for_saturday,
        "is_animal_festival": is_animal_fest,
        "target_npcs_count": len(target_npcs),
        "covered_npcs_count": len(covered_npcs),
        "unlocked_npcs_count": unlocked_npcs_count,
        "unlocked_vendors_count": unlocked_vendors_count,
        "unlocked_townsfolk_count": unlocked_townsfolk_count,
        "slots_used": len(bag_plan),
        "max_slots": max_slots,
        "today_loved_completed": today_loved_count,
        "today_liked_completed": today_liked_count,
        "today_total_completed": today_loved_count + today_liked_count,
        "vendors_covered_today": vendors_covered_today,
        "game_total_loved": total_game_loved,
        "game_total_liked": total_game_liked,
        "game_total_preferences": total_game_loved + total_game_liked,
        "game_given_loved": total_given_loved,
        "game_given_liked": total_given_liked,
        "game_given_total": total_given_loved + total_given_liked,
        "remaining_unique_items": len(all_remaining_items_map),
        "ungiftable_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in ungiftable_npcs if nid in npc_gift_definitions],
        "not_present_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in not_present_npcs if nid in npc_gift_definitions],
        "locked_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in locked_npcs if nid in npc_gift_definitions],
        "max_relationship_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in max_relationship_npcs if nid in npc_gift_definitions],
        "max_relationship_npcs_count": len(max_relationship_npcs),
        "completed_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in completed_npcs if nid in npc_gift_definitions],
        "completed_npcs_count": len(completed_npcs),
        "done_npcs": [npc_gift_definitions[nid].get("name", nid) for nid in completed_npcs if nid in npc_gift_definitions],
        "done_npcs_count": len(completed_npcs),
        "infused_items_detected": total_infused_detected,
    }

    if all_seasons:
        effective_season = None
    elif current_season is not None:
        effective_season = current_season
    elif save is not None and hasattr(save, "in_game_date") and save.in_game_date is not None:
        effective_season = getattr(save.in_game_date, "season", None)
    else:
        effective_season = None

    overall_stats["current_season"] = effective_season
    overall_stats["all_seasons"] = all_seasons or (effective_season is None)
    overall_stats["seasonal_boost"] = seasonal_boost

    focus_remaining_map = (
        filter_remaining_items_for_focus(all_remaining_items_map, focus_npcs)
        if (focus_mode_enabled and focus_npcs)
        else all_remaining_items_map
    )

    focus_suggestions = compute_focus_suggestions(
        remaining_items_map=all_remaining_items_map,
        inventory=initial_inventory,
        recipes=all_recipes,
        item_metadata=item_metadata,
        top_n=focus_top_n,
        item_locations=item_locations,
        focus_sort=focus_sort,
        current_season=effective_season,
        item_seasons=item_seasons,
        seasonal_boost=seasonal_boost,
        focus_mode_enabled=focus_mode_enabled,
        focus_npcs=focus_npcs,
    )

    all_unobtained_recipes, recipe_unlock_stats = compute_focus_recipes(
        all_recipes=all_recipes,
        unlocked_recipe_ids=unlocked if (save is not None) else None,
        remaining_items_map=all_remaining_items_map,
        recipe_sources=recipe_sources,
        top_n=None,
    )
    focus_recipes = all_unobtained_recipes[:10]

    alt_sources_data = load_alt_sources() if alt_sources is None else alt_sources

    npc_names_map = {
        nid.lower(): data.get("name", nid.capitalize())
        for nid, data in npc_gift_definitions.items()
        if isinstance(data, dict)
    }

    focus_trees = build_focus_crafting_trees(
        focus_suggestions=focus_suggestions,
        recipes=all_recipes,
        remaining_items_map=focus_remaining_map,
        alt_sources=alt_sources_data,
        item_metadata=item_metadata,
        npc_names=npc_names_map,
    )

    source_priority = compute_source_priorities(
        focus_suggestions=focus_suggestions,
        item_locations=item_locations,
        alt_sources=alt_sources_data,
        npc_names=npc_names_map,
    )

    return {
        "bag_plan": bag_plan,
        "npc_progress": npc_progress,
        "covered_npcs": covered_npcs,
        "target_npcs": target_npcs,
        "remaining_items_map": all_remaining_items_map,
        "all_remaining_items_map": all_remaining_items_map,
        "today_remaining_items_map": today_remaining_items_map,
        "focus_suggestions": focus_suggestions,
        "focus_recipes": focus_recipes,
        "all_unobtained_recipes": all_unobtained_recipes,
        "recipe_unlock_stats": recipe_unlock_stats,
        "focus_trees": focus_trees,
        "source_priority": source_priority,
        "alt_sources": alt_sources_data,
        "focus_sort": focus_sort,
        "current_season": effective_season,
        "all_seasons": all_seasons or (effective_season is None),
        "seasonal_boost": seasonal_boost,
        "overall_stats": overall_stats,
        "infused_items": raw_infused,
    }


